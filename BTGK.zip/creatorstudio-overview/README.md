# CreatorStudio – Tổng quan dự án (Khách hàng)

Chỉ có màn hình **Tổng quan dự án**, không đăng nhập, không có dữ liệu dự án mẫu (hiện trạng thái rỗng, có thể tạo dự án mới).

Chạy thử: mở `client-project-overview.html`. Dữ liệu lưu trong LocalStorage của trình duyệt.
