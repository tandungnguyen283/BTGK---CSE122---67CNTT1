/* Dữ liệu giả lập ban đầu (seed). Toàn bộ dữ liệu nghiệp vụ nằm ở đây, không viết cứng trong HTML. */
window.CS = window.CS || {};

CS.SEED = {
  users: [{ id: "u1", name: "Khách hàng", email: "client@demo.vn", role: "client", status: "active" }],
  projects: [], briefs: [], moodboards: [], versions: [], comments: [], tasks: [], templates: []
};
