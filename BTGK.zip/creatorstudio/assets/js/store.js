/* Lớp dữ liệu: LocalStorage + API giả lập có độ trễ/lỗi để minh họa trạng thái đang tải/lỗi/rỗng. */
(function () {
  const KEY = "creatorstudio_overview_v1";

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      const d = raw && JSON.parse(raw);
      if (d && Array.isArray(d.projects)) return d;
    } catch (e) { /* bỏ qua, dùng dữ liệu ban đầu */ }
    return JSON.parse(JSON.stringify(CS.SEED));
  }
  let db = load();
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* hết dung lượng: giữ trong bộ nhớ */ }
  }
  function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 8); }

  const store = {
    list(entity) { return (db[entity] || []).slice(); },
    get(entity, id) { return (db[entity] || []).find((x) => x.id === id) || null; },
    add(entity, obj) {
      const rec = Object.assign({ id: uid(entity[0]) }, obj);
      db[entity] = db[entity] || [];
      db[entity].push(rec); save(); return rec;
    },
    update(entity, id, patch) {
      const rec = store.get(entity, id);
      if (!rec) return null;
      Object.assign(rec, patch); save(); return rec;
    },
    remove(entity, id) {
      db[entity] = (db[entity] || []).filter((x) => x.id !== id); save();
    }
  };

  /* API giả lập: trả Promise, bật lỗi bằng ?fail=1 trên URL để xem trạng thái lỗi. */
  const api = {
    delay: 450,
    list(entity, filterFn) {
      const forceFail = new URLSearchParams(location.search).get("fail") === "1";
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          if (forceFail) return reject(new Error("Không thể tải dữ liệu. Vui lòng thử lại."));
          const rows = store.list(entity);
          resolve(filterFn ? rows.filter(filterFn) : rows);
        }, api.delay);
      });
    }
  };

  CS.store = store; CS.api = api; CS.uid = uid;
})();
