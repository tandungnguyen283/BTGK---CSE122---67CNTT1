/* Dữ liệu ban đầu: chỉ có một tài khoản khách hàng, không có dự án mẫu. */
window.CS = window.CS || {};

CS.SEED = {
  users: [{ id: "u1", name: "Khách hàng", email: "client@creatorstudio.vn", role: "client", status: "active" }],
  projects: []
};
