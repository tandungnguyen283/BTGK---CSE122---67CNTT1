/* Thành phần giao diện dùng chung: khung trang, toast, modal, trạng thái, kiểm tra hợp lệ. */
(function () {
  const ui = {
    esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    },
    fmtDate(d) {
      if (!d) return "—";
      const p = String(d).split("-");
      return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : d;
    },
    today() { return new Date().toISOString().slice(0, 10); },

    /* Dựng khung (topbar) quanh <main id="main"> và trả về khách hàng hiện tại */
    init() {
      const user = CS.store.list("users")[0];
      const main = document.getElementById("main");
      const top = document.createElement("header");
      top.className = "topbar";
      top.innerHTML = `
        <a class="brand" href="client-project-overview.html"><span class="brand-mark" aria-hidden="true">C</span>CreatorStudio</a>
        <span class="topbar-spacer"></span>
        <div class="user-chip"><span class="role-tag">Khách hàng</span><span class="name">${ui.esc(user.name)}</span></div>`;
      const skip = document.createElement("a");
      skip.className = "skip-link"; skip.href = "#main"; skip.textContent = "Bỏ qua điều hướng";
      main.parentNode.insertBefore(skip, main);
      main.parentNode.insertBefore(top, main);
      main.setAttribute("tabindex", "-1");

      const host = document.createElement("div");
      host.className = "toast-host"; host.id = "toastHost"; host.setAttribute("aria-live", "polite");
      document.body.appendChild(host);
      ui.wireModals();
      return user;
    },

    toast(msg, type) {
      const host = document.getElementById("toastHost");
      const t = document.createElement("div");
      t.className = "toast " + (type || ""); t.textContent = msg;
      host.appendChild(t);
      setTimeout(() => t.remove(), 3200);
    },

    /* Modal truy cập được: đóng bằng Esc / nút / bấm nền, trả focus */
    wireModals() {
      document.querySelectorAll(".modal-back").forEach((m) => {
        m.addEventListener("click", (e) => { if (e.target === m || e.target.closest("[data-close]")) ui.closeModal(m.id); });
      });
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") document.querySelectorAll(".modal-back.open").forEach((m) => ui.closeModal(m.id));
      });
    },
    openModal(id) {
      const m = document.getElementById(id);
      ui._last = document.activeElement;
      m.classList.add("open");
      const f = m.querySelector("input, select, textarea, button");
      if (f) f.focus();
    },
    closeModal(id) {
      document.getElementById(id).classList.remove("open");
      if (ui._last && ui._last.focus) ui._last.focus();
    },
    confirm(message) { return window.confirm(message); },

    /* Trạng thái: loading | empty | error */
    state(el, kind, opts) {
      opts = opts || {};
      if (kind === "loading") {
        el.innerHTML = '<div role="status" aria-label="Đang tải"><div class="skeleton lg"></div><div class="skeleton"></div><div class="skeleton" style="width:70%"></div></div>';
      } else if (kind === "empty") {
        el.innerHTML = `<div class="state"><span class="ico" aria-hidden="true">${opts.icon || "📭"}</span><p>${ui.esc(opts.msg || "Chưa có dữ liệu.")}</p>${opts.action || ""}</div>`;
      } else if (kind === "error") {
        el.innerHTML = `<div class="state error" role="alert"><span class="ico" aria-hidden="true">⚠️</span><p>${ui.esc(opts.msg || "Đã xảy ra lỗi.")}</p><button class="btn sm" data-retry>Thử lại</button></div>`;
        const b = el.querySelector("[data-retry]");
        if (b && opts.onRetry) b.onclick = opts.onRetry;
      }
    },

    /* Kiểm tra hợp lệ: required, minlength, data-future (ngày không ở quá khứ) */
    validate(form) {
      let ok = true; let first = null;
      form.querySelectorAll("input, select, textarea").forEach((f) => {
        const v = (f.value || "").trim();
        let msg = "";
        if (f.hasAttribute("required") && !v) msg = "Trường này là bắt buộc.";
        else if (v && f.minLength > 0 && v.length < f.minLength) msg = "Cần ít nhất " + f.minLength + " ký tự.";
        else if (v && f.dataset.future === "1" && v < ui.today()) msg = "Ngày không được ở quá khứ.";
        const err = f.parentElement.querySelector(".field-error");
        if (err) err.textContent = msg;
        f.setAttribute("aria-invalid", msg ? "true" : "false");
        if (msg) { ok = false; if (!first) first = f; }
      });
      if (first) first.focus();
      return ok;
    },

    statusBadge(status) {
      const map = {
        active: ["Đang chạy", "ok"], paused: ["Tạm dừng", "warn"],
        done: ["Hoàn thành", "ok"], archived: ["Đã lưu trữ", ""]
      };
      const m = map[status] || [status, ""];
      return `<span class="badge ${m[1]}">${m[0]}</span>`;
    }
  };

  CS.ui = ui;
})();
