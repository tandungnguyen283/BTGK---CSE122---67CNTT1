# CreatorStudio – Tổng quan dự án (Khách hàng)

Nguyên mẫu **frontend thuần** (HTML + CSS + JavaScript), không cần máy chủ. Chỉ giữ màn hình **Tổng quan dự án** của khách hàng, không có dữ liệu mẫu.

## Chạy thử

Mở `client-project-overview.html` bằng trình duyệt (hoặc `python3 -m http.server`).

Chức năng: tạo / sửa / lưu trữ / khôi phục / xóa dự án, tìm theo tên, lọc theo trạng thái, thống kê nhanh. Dữ liệu lưu ở LocalStorage (khóa `creatorstudio_overview_v1`).
Thêm `?fail=1` vào URL để xem trạng thái lỗi + nút Thử lại.

## Cấu trúc

```text
client-project-overview.html
assets/css/styles.css                       hệ thống thiết kế
assets/js/data.js                           dữ liệu ban đầu (rỗng)
assets/js/store.js                          LocalStorage + API giả lập
assets/js/ui.js                             khung trang, toast, modal, validate
assets/js/pages/client-project-overview.js  logic màn hình
```
